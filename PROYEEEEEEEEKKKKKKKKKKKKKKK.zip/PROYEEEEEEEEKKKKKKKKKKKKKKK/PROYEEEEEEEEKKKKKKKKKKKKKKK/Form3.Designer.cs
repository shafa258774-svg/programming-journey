﻿
namespace PROYEEEEEEEEKKKKKKKKKKKKKKK
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            label5 = new Label();
            labelBuy = new Label();
            labelPaymentMethod = new Label();
            labelPrice = new Label();
            labeldrinkName = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Cornsilk;
            label5.Font = new Font("Bookman Old Style", 12.1846151F);
            label5.Location = new Point(546, 287);
            label5.Name = "label5";
            label5.Size = new Size(86, 25);
            label5.TabIndex = 9;
            label5.Text = "Cancel";
            label5.Click += label5_Click;
            // 
            // labelBuy
            // 
            labelBuy.AutoSize = true;
            labelBuy.BackColor = Color.Cornsilk;
            labelBuy.Font = new Font("Bookman Old Style", 12.1846151F);
            labelBuy.Location = new Point(398, 287);
            labelBuy.Name = "labelBuy";
            labelBuy.Size = new Size(55, 25);
            labelBuy.TabIndex = 8;
            labelBuy.Text = "Buy";
            labelBuy.Click += label4_Click;
            // 
            // labelPaymentMethod
            // 
            labelPaymentMethod.AutoSize = true;
            labelPaymentMethod.Font = new Font("Bookman Old Style", 12.1846151F);
            labelPaymentMethod.Location = new Point(36, 173);
            labelPaymentMethod.Name = "labelPaymentMethod";
            labelPaymentMethod.Size = new Size(0, 25);
            labelPaymentMethod.TabIndex = 7;
            labelPaymentMethod.Click += labelPaymentMethod_Click;
            // 
            // labelPrice
            // 
            labelPrice.AutoSize = true;
            labelPrice.Font = new Font("Bookman Old Style", 12.1846151F);
            labelPrice.Location = new Point(36, 106);
            labelPrice.Name = "labelPrice";
            labelPrice.Size = new Size(241, 25);
            labelPrice.TabIndex = 6;
            labelPrice.Text = "Price                        :";
            // 
            // labeldrinkName
            // 
            labeldrinkName.AutoSize = true;
            labeldrinkName.Font = new Font("Bookman Old Style", 12.1846151F);
            labeldrinkName.Location = new Point(36, 41);
            labeldrinkName.Name = "labeldrinkName";
            labeldrinkName.Size = new Size(242, 25);
            labeldrinkName.TabIndex = 5;
            labeldrinkName.Text = "Product Name          :";
            labeldrinkName.Click += labelProductName_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Bookman Old Style", 12.1846151F);
            label1.Location = new Point(37, 173);
            label1.Name = "label1";
            label1.Size = new Size(223, 25);
            label1.TabIndex = 10;
            label1.Text = "Payment Method   :";
            label1.Click += label1_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSteelBlue;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(678, 362);
            Controls.Add(label1);
            Controls.Add(label5);
            Controls.Add(labelBuy);
            Controls.Add(labelPaymentMethod);
            Controls.Add(labelPrice);
            Controls.Add(labeldrinkName);
            Name = "Form3";
            Text = "Form3";
            Load += Form3_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        private void labelProductName_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void labelPaymentMethod_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private Label label5;
        private Label labelBuy;
        private Label labelPaymentMethod;
        private Label labelPrice;
        private Label labeldrinkName;
        private Label label1;
    }
}