namespace PROYEEEEEEEEKKKKKKKKKKKKKKK
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnBuy1_Click(object sender, EventArgs e)
        {
            string drinkName = "Monster Zero Ultra White";
            string price = "Rp 35.000";
            Form2 form2 = new Form2(drinkName, price);
            form2.Show();
            this.Hide();
        }

        private void btnBuy2_Click(object sender, EventArgs e)
        {
            string drinkName = "Java Monster Loca Moca";
            string price = "Rp 40.000";
            Form2 form2 = new Form2(drinkName, price);
            form2.Show();
            this.Hide();
        }

        private void btnBuy3_Click(object sender, EventArgs e)
        {
            string drinkName = "Java Monster Salted Caramel";
            string price = "Rp 55.500";
            Form2 form2 = new Form2(drinkName, price);
            form2.Show();
            this.Hide();
        }

        private void btnBuy4_Click(object sender, EventArgs e)
        {
            string drinkName = "Monster Assault";
            string price = "Rp 45.000";
            Form2 form2 = new Form2(drinkName, price);
            form2.Show();
            this.Hide();
        }

        private void btnBuy5_Click(object sender, EventArgs e)
        {
            string drinkName = "Monster Ultra Black";
            string price = "Rp 48.000";
            Form2 form2 = new Form2(drinkName, price);
            form2.Show();
            this.Hide();
        }

        private void btnBuy6_Click(object sender, EventArgs e)
        {
            string drinkName = "Monster";
            string price = "Rp 30.000";
            Form2 form2 = new Form2(drinkName, price);
            form2.Show();
            this.Hide();
        }

        private void btnBuy7_Click(object sender, EventArgs e)
        {
            string drinkName = "Red Bull";
            string price = "Rp 25.000";
            Form2 form2 = new Form2(drinkName, price);
            form2.Show();
            this.Hide();
        }

        private void btnBuy8_Click(object sender, EventArgs e)
        {
            string drinkName = "Sprite";
            string price = "Rp 5.500";
            Form2 form2 = new Form2(drinkName, price);
            form2.Show();
            this.Hide();
        }

        private void btnBuy9_Click(object sender, EventArgs e)
        {
            string drinkName = "Fanta Orange";
            string price = "Rp 6.500";
            Form2 form2 = new Form2(drinkName, price);
            form2.Show();
            this.Hide();
        }

        private void btnBuy10_Click(object sender, EventArgs e)
        {
            string drinkName = "Coca Cola Classic";
            string price = "Rp 8.500";
            Form2 form2 = new Form2(drinkName, price);
            form2.Show();
            this.Hide();
        }

        private void btnBuy11_Click(object sender, EventArgs e)
        {
            string drinkName = "Pepsi";
            string price = "Rp 28.500";
            Form2 form2 = new Form2(drinkName, price);
            form2.Show();
            this.Hide();
        }

        private void btnBuy12_Click(object sender, EventArgs e)
        {
            string drinkName = "Dr. Pepper";
            string price = "Rp 19.500";
            Form2 form2 = new Form2(drinkName, price);
            form2.Show();
            this.Hide();
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }
    }
}
