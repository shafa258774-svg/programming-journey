﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace PROYEEEEEEEEKKKKKKKKKKKKKKK
{
    public partial class Form2 : Form
    {
        private string drinkName;
        private string price;
        public Form2(string drinkName, string price)
        {
            InitializeComponent();
            this.drinkName = drinkName;
            this.price = price;
        }

        private void comboBoxEWallet_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxMobileBanking.SelectedIndex = -1;
        }
        private void comboBoxMobileBanking_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxEWallet.SelectedIndex = -1;
        }
        private void btnBuy_Click(object sender, EventArgs e)
        {
            string paymentMethod = "";

            // Cek metode pembayaran yang dipilih
            if (comboBoxEWallet.SelectedItem != null)
                paymentMethod = comboBoxEWallet.SelectedItem.ToString();
            else if (comboBoxMobileBanking.SelectedItem != null)
                paymentMethod = comboBoxMobileBanking.SelectedItem.ToString();
            else
            {
                MessageBox.Show("Lu mau bayar pake apa?");
                return;
            }
            Form3 form3 = new Form3(paymentMethod, drinkName, price);
            form3.Show();
            this.Hide();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
