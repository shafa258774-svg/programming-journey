﻿
namespace PROYEEEEEEEEKKKKKKKKKKKKKKK
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            btnCancel = new Button();
            btnBuy = new Button();
            label3 = new Label();
            label2 = new Label();
            comboBoxMobileBanking = new ComboBox();
            comboBoxEWallet = new ComboBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.LightCoral;
            btnCancel.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCancel.Location = new Point(361, 304);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(102, 31);
            btnCancel.TabIndex = 20;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnBuy
            // 
            btnBuy.BackColor = Color.Cornsilk;
            btnBuy.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBuy.Location = new Point(234, 304);
            btnBuy.Name = "btnBuy";
            btnBuy.Size = new Size(102, 31);
            btnBuy.TabIndex = 19;
            btnBuy.Text = "Buy";
            btnBuy.UseVisualStyleBackColor = false;
            btnBuy.Click += btnBuy_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Bookman Old Style", 11.0769234F);
            label3.Location = new Point(52, 189);
            label3.Name = "label3";
            label3.Size = new Size(162, 23);
            label3.TabIndex = 18;
            label3.Text = "Mobile Banking";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.System;
            label2.Font = new Font("Bookman Old Style", 11.0769234F);
            label2.Location = new Point(55, 138);
            label2.Name = "label2";
            label2.Size = new Size(93, 23);
            label2.TabIndex = 17;
            label2.Text = "E-Wallet";
            label2.Click += label2_Click;
            // 
            // comboBoxMobileBanking
            // 
            comboBoxMobileBanking.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxMobileBanking.FormattingEnabled = true;
            comboBoxMobileBanking.Items.AddRange(new object[] { "BRImo", "BCA Mobile", "Livin' By Mandiri", "BNI Mobile Banking" });
            comboBoxMobileBanking.Location = new Point(234, 192);
            comboBoxMobileBanking.Name = "comboBoxMobileBanking";
            comboBoxMobileBanking.Size = new Size(229, 29);
            comboBoxMobileBanking.TabIndex = 16;
            comboBoxMobileBanking.SelectedIndexChanged += comboBoxMobileBanking_SelectedIndexChanged;
            // 
            // comboBoxEWallet
            // 
            comboBoxEWallet.BackColor = SystemColors.Control;
            comboBoxEWallet.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxEWallet.FormattingEnabled = true;
            comboBoxEWallet.Items.AddRange(new object[] { "OVO", "DANA", "GoPay", "ShopeePay" });
            comboBoxEWallet.Location = new Point(234, 137);
            comboBoxEWallet.Name = "comboBoxEWallet";
            comboBoxEWallet.Size = new Size(229, 29);
            comboBoxEWallet.TabIndex = 15;
            comboBoxEWallet.SelectedIndexChanged += comboBoxEWallet_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("GeoSlab703 Md BT", 19.9384613F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(62, 42);
            label1.Name = "label1";
            label1.Size = new Size(396, 43);
            label1.TabIndex = 14;
            label1.Text = "mau bayar pake apa?";
            label1.Click += label1_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSteelBlue;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(538, 394);
            Controls.Add(btnCancel);
            Controls.Add(btnBuy);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(comboBoxMobileBanking);
            Controls.Add(comboBoxEWallet);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        

        private void label2_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private Button btnCancel;
        private Button btnBuy;
        private Label label3;
        private Label label2;
        private ComboBox comboBoxMobileBanking;
        private ComboBox comboBoxEWallet;
        private Label label1;
    }
}