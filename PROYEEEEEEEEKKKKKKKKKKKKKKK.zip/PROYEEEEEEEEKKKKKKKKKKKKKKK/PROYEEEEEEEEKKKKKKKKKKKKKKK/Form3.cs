﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROYEEEEEEEEKKKKKKKKKKKKKKK
{
    public partial class Form3 : Form
    {
        private string PaymentMethod;
        private string drinkName;
        private string price;
        public Form3(string PaymentMethod, string drinkName, string price)
        {
            InitializeComponent();
            this.PaymentMethod = PaymentMethod;
            this.drinkName = drinkName;
            this.price = price;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            labeldrinkName.Text = $"Product Name       : {drinkName}";
            labelPrice.Text = $"Price                     : {this.price}";
            labelPaymentMethod.Text = $"Payment Method   : {this.PaymentMethod}";
        }

        private void label5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Yatta! Payment berhasil! >.<");

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
