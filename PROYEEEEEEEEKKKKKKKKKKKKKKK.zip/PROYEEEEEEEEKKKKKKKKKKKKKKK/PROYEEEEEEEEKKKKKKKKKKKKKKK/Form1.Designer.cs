﻿namespace PROYEEEEEEEEKKKKKKKKKKKKKKK
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            btnBuy12 = new Button();
            btnBuy11 = new Button();
            btnBuy10 = new Button();
            btnBuy9 = new Button();
            btnBuy8 = new Button();
            btnBuy7 = new Button();
            btnBuy6 = new Button();
            btnBuy5 = new Button();
            btnBuy4 = new Button();
            btnBuy3 = new Button();
            btnBuy2 = new Button();
            btnBuy1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button6 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button7 = new Button();
            button9 = new Button();
            button5 = new Button();
            button4 = new Button();
            button1 = new Button();
            button8 = new Button();
            SuspendLayout();
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            label12.Location = new Point(864, 533);
            label12.Name = "label12";
            label12.Size = new Size(96, 19);
            label12.TabIndex = 74;
            label12.Text = "Rp 19.500";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            label11.Location = new Point(711, 533);
            label11.Name = "label11";
            label11.Size = new Size(97, 19);
            label11.TabIndex = 73;
            label11.Text = "Rp 28.500";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            label10.Location = new Point(555, 533);
            label10.Name = "label10";
            label10.Size = new Size(86, 19);
            label10.TabIndex = 72;
            label10.Text = "Rp 8.000";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            label9.Location = new Point(391, 533);
            label9.Name = "label9";
            label9.Size = new Size(86, 19);
            label9.TabIndex = 71;
            label9.Text = "Rp 6.500";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            label8.Location = new Point(230, 533);
            label8.Name = "label8";
            label8.Size = new Size(86, 19);
            label8.TabIndex = 70;
            label8.Text = "Rp 5.500";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            label7.Location = new Point(55, 533);
            label7.Name = "label7";
            label7.Size = new Size(97, 19);
            label7.TabIndex = 69;
            label7.Text = "Rp 25.000";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            label6.Location = new Point(865, 213);
            label6.Name = "label6";
            label6.Size = new Size(97, 19);
            label6.TabIndex = 68;
            label6.Text = "Rp 30.000";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            label5.Location = new Point(709, 213);
            label5.Name = "label5";
            label5.Size = new Size(97, 19);
            label5.TabIndex = 67;
            label5.Text = "Rp 48.000";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            label4.Location = new Point(551, 213);
            label4.Name = "label4";
            label4.Size = new Size(97, 19);
            label4.TabIndex = 66;
            label4.Text = "Rp 45.000";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            label3.Location = new Point(386, 213);
            label3.Name = "label3";
            label3.Size = new Size(97, 19);
            label3.TabIndex = 65;
            label3.Text = "Rp 40.000";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            label2.Location = new Point(224, 213);
            label2.Name = "label2";
            label2.Size = new Size(97, 19);
            label2.TabIndex = 64;
            label2.Text = "Rp 40.000";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            label1.Location = new Point(59, 212);
            label1.Name = "label1";
            label1.Size = new Size(97, 19);
            label1.TabIndex = 63;
            label1.Text = "Rp 35.000";
            // 
            // btnBuy12
            // 
            btnBuy12.BackColor = SystemColors.Info;
            btnBuy12.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            btnBuy12.Location = new Point(874, 568);
            btnBuy12.Name = "btnBuy12";
            btnBuy12.Size = new Size(77, 29);
            btnBuy12.TabIndex = 62;
            btnBuy12.Text = "Buy";
            btnBuy12.UseVisualStyleBackColor = false;
            btnBuy12.Click += btnBuy12_Click;
            // 
            // btnBuy11
            // 
            btnBuy11.BackColor = SystemColors.Info;
            btnBuy11.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            btnBuy11.Location = new Point(720, 568);
            btnBuy11.Name = "btnBuy11";
            btnBuy11.Size = new Size(77, 29);
            btnBuy11.TabIndex = 61;
            btnBuy11.Text = "Buy";
            btnBuy11.UseVisualStyleBackColor = false;
            btnBuy11.Click += btnBuy11_Click;
            // 
            // btnBuy10
            // 
            btnBuy10.BackColor = SystemColors.Info;
            btnBuy10.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            btnBuy10.Location = new Point(560, 568);
            btnBuy10.Name = "btnBuy10";
            btnBuy10.Size = new Size(77, 29);
            btnBuy10.TabIndex = 60;
            btnBuy10.Text = "Buy";
            btnBuy10.UseVisualStyleBackColor = false;
            btnBuy10.Click += btnBuy10_Click;
            // 
            // btnBuy9
            // 
            btnBuy9.BackColor = SystemColors.Info;
            btnBuy9.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            btnBuy9.Location = new Point(397, 568);
            btnBuy9.Name = "btnBuy9";
            btnBuy9.Size = new Size(77, 29);
            btnBuy9.TabIndex = 59;
            btnBuy9.Text = "Buy";
            btnBuy9.UseVisualStyleBackColor = false;
            btnBuy9.Click += btnBuy9_Click;
            // 
            // btnBuy8
            // 
            btnBuy8.BackColor = SystemColors.Info;
            btnBuy8.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            btnBuy8.Location = new Point(234, 568);
            btnBuy8.Name = "btnBuy8";
            btnBuy8.Size = new Size(77, 29);
            btnBuy8.TabIndex = 58;
            btnBuy8.Text = "Buy";
            btnBuy8.UseVisualStyleBackColor = false;
            btnBuy8.Click += btnBuy8_Click;
            // 
            // btnBuy7
            // 
            btnBuy7.BackColor = SystemColors.Info;
            btnBuy7.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            btnBuy7.Location = new Point(66, 568);
            btnBuy7.Name = "btnBuy7";
            btnBuy7.Size = new Size(77, 29);
            btnBuy7.TabIndex = 57;
            btnBuy7.Text = "Buy";
            btnBuy7.UseVisualStyleBackColor = false;
            btnBuy7.Click += btnBuy7_Click;
            // 
            // btnBuy6
            // 
            btnBuy6.BackColor = SystemColors.Info;
            btnBuy6.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            btnBuy6.Location = new Point(875, 248);
            btnBuy6.Name = "btnBuy6";
            btnBuy6.Size = new Size(77, 29);
            btnBuy6.TabIndex = 56;
            btnBuy6.Text = "Buy";
            btnBuy6.UseVisualStyleBackColor = false;
            btnBuy6.Click += btnBuy6_Click;
            // 
            // btnBuy5
            // 
            btnBuy5.BackColor = SystemColors.Info;
            btnBuy5.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            btnBuy5.Location = new Point(719, 249);
            btnBuy5.Name = "btnBuy5";
            btnBuy5.Size = new Size(77, 29);
            btnBuy5.TabIndex = 55;
            btnBuy5.Text = "Buy";
            btnBuy5.UseVisualStyleBackColor = false;
            btnBuy5.Click += btnBuy5_Click;
            // 
            // btnBuy4
            // 
            btnBuy4.BackColor = SystemColors.Info;
            btnBuy4.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            btnBuy4.Location = new Point(564, 249);
            btnBuy4.Name = "btnBuy4";
            btnBuy4.Size = new Size(77, 29);
            btnBuy4.TabIndex = 54;
            btnBuy4.Text = "Buy";
            btnBuy4.UseVisualStyleBackColor = false;
            btnBuy4.Click += btnBuy4_Click;
            // 
            // btnBuy3
            // 
            btnBuy3.BackColor = SystemColors.Info;
            btnBuy3.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            btnBuy3.Location = new Point(395, 249);
            btnBuy3.Name = "btnBuy3";
            btnBuy3.Size = new Size(77, 29);
            btnBuy3.TabIndex = 53;
            btnBuy3.Text = "Buy";
            btnBuy3.UseVisualStyleBackColor = false;
            btnBuy3.Click += btnBuy3_Click;
            // 
            // btnBuy2
            // 
            btnBuy2.BackColor = SystemColors.Info;
            btnBuy2.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            btnBuy2.Location = new Point(234, 248);
            btnBuy2.Name = "btnBuy2";
            btnBuy2.Size = new Size(77, 29);
            btnBuy2.TabIndex = 52;
            btnBuy2.Text = "Buy";
            btnBuy2.UseVisualStyleBackColor = false;
            btnBuy2.Click += btnBuy2_Click;
            // 
            // btnBuy1
            // 
            btnBuy1.BackColor = SystemColors.Info;
            btnBuy1.Font = new Font("Bookman Old Style", 8.861538F, FontStyle.Bold);
            btnBuy1.Location = new Point(69, 248);
            btnBuy1.Name = "btnBuy1";
            btnBuy1.Size = new Size(77, 29);
            btnBuy1.TabIndex = 51;
            btnBuy1.Text = "Buy";
            btnBuy1.UseVisualStyleBackColor = false;
            btnBuy1.Click += btnBuy1_Click;
            // 
            // button2
            // 
            button2.BackgroundImage = (Image)resources.GetObject("button2.BackgroundImage");
            button2.BackgroundImageLayout = ImageLayout.Zoom;
            button2.Location = new Point(863, 351);
            button2.Name = "button2";
            button2.Size = new Size(97, 164);
            button2.TabIndex = 50;
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.BackgroundImage = (Image)resources.GetObject("button3.BackgroundImage");
            button3.BackgroundImageLayout = ImageLayout.Zoom;
            button3.Location = new Point(58, 352);
            button3.Name = "button3";
            button3.Size = new Size(89, 166);
            button3.TabIndex = 48;
            button3.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.BackgroundImage = (Image)resources.GetObject("button6.BackgroundImage");
            button6.BackgroundImageLayout = ImageLayout.Zoom;
            button6.Location = new Point(549, 352);
            button6.Name = "button6";
            button6.Size = new Size(97, 164);
            button6.TabIndex = 47;
            button6.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.BackgroundImage = (Image)resources.GetObject("button10.BackgroundImage");
            button10.BackgroundImageLayout = ImageLayout.Zoom;
            button10.Location = new Point(709, 351);
            button10.Name = "button10";
            button10.Size = new Size(97, 165);
            button10.TabIndex = 46;
            button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            button11.BackgroundImage = (Image)resources.GetObject("button11.BackgroundImage");
            button11.BackgroundImageLayout = ImageLayout.Zoom;
            button11.Location = new Point(391, 352);
            button11.Name = "button11";
            button11.Size = new Size(89, 166);
            button11.TabIndex = 45;
            button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            button12.BackgroundImage = (Image)resources.GetObject("button12.BackgroundImage");
            button12.BackgroundImageLayout = ImageLayout.Zoom;
            button12.Location = new Point(224, 352);
            button12.Name = "button12";
            button12.Size = new Size(97, 165);
            button12.TabIndex = 49;
            button12.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.BackgroundImage = (Image)resources.GetObject("button7.BackgroundImage");
            button7.BackgroundImageLayout = ImageLayout.Zoom;
            button7.Location = new Point(383, 34);
            button7.Name = "button7";
            button7.Size = new Size(97, 164);
            button7.TabIndex = 44;
            button7.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.BackgroundImage = (Image)resources.GetObject("button9.BackgroundImage");
            button9.BackgroundImageLayout = ImageLayout.Zoom;
            button9.Location = new Point(227, 32);
            button9.Name = "button9";
            button9.Size = new Size(89, 166);
            button9.TabIndex = 42;
            button9.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.BackgroundImage = (Image)resources.GetObject("button5.BackgroundImage");
            button5.BackgroundImageLayout = ImageLayout.Zoom;
            button5.Location = new Point(58, 34);
            button5.Name = "button5";
            button5.Size = new Size(97, 164);
            button5.TabIndex = 41;
            button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.BackgroundImage = (Image)resources.GetObject("button4.BackgroundImage");
            button4.BackgroundImageLayout = ImageLayout.Zoom;
            button4.Location = new Point(863, 35);
            button4.Name = "button4";
            button4.Size = new Size(97, 165);
            button4.TabIndex = 40;
            button4.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.BackgroundImage = (Image)resources.GetObject("button1.BackgroundImage");
            button1.BackgroundImageLayout = ImageLayout.Stretch;
            button1.Location = new Point(712, 33);
            button1.Name = "button1";
            button1.Size = new Size(89, 166);
            button1.TabIndex = 39;
            button1.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            button8.BackgroundImage = (Image)resources.GetObject("button8.BackgroundImage");
            button8.BackgroundImageLayout = ImageLayout.Zoom;
            button8.Location = new Point(549, 35);
            button8.Name = "button8";
            button8.Size = new Size(97, 165);
            button8.TabIndex = 43;
            button8.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSteelBlue;
            ClientSize = new Size(1017, 632);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnBuy12);
            Controls.Add(btnBuy11);
            Controls.Add(btnBuy10);
            Controls.Add(btnBuy9);
            Controls.Add(btnBuy8);
            Controls.Add(btnBuy7);
            Controls.Add(btnBuy6);
            Controls.Add(btnBuy5);
            Controls.Add(btnBuy4);
            Controls.Add(btnBuy3);
            Controls.Add(btnBuy2);
            Controls.Add(btnBuy1);
            Controls.Add(button2);
            Controls.Add(button3);
            Controls.Add(button6);
            Controls.Add(button10);
            Controls.Add(button11);
            Controls.Add(button12);
            Controls.Add(button7);
            Controls.Add(button9);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button1);
            Controls.Add(button8);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load_1;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label12;
        private Label label11;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button btnBuy12;
        private Button btnBuy11;
        private Button btnBuy10;
        private Button btnBuy9;
        private Button btnBuy8;
        private Button btnBuy7;
        private Button btnBuy6;
        private Button btnBuy5;
        private Button btnBuy4;
        private Button btnBuy3;
        private Button btnBuy2;
        private Button btnBuy1;
        private Button button2;
        private Button button3;
        private Button button6;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button7;
        private Button button9;
        private Button button5;
        private Button button4;
        private Button button1;
        private Button button8;
    }
}
